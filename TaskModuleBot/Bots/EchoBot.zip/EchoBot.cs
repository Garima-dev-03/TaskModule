// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.
//
// Generated with Bot Builder V4 SDK Template for Visual Studio EchoBot v4.11.1

using AdaptiveCards;
using Microsoft.Bot;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Schema;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Bot.Builder.Teams;
using Microsoft.Bot.Schema.Teams;   //add
using Newtonsoft.Json;   //add

namespace TaskModuleBot.Bots
{
    public class EchoBot : TeamsActivityHandler
    {
        protected override async Task OnMessageActivityAsync(ITurnContext<IMessageActivity> turnContext, CancellationToken cancellationToken)
        {
            var reply = MessageFactory.Attachment(GetAdaptiveCard());
            await turnContext.SendActivityAsync(reply);
            //await turnContext.SendActivityAsync(MessageFactory.Attachment(GetAdaptiveCard()), cancellationToken);
        }

        protected override async Task OnMembersAddedAsync(IList<ChannelAccount> membersAdded, ITurnContext<IConversationUpdateActivity> turnContext, CancellationToken cancellationToken)
        {
            var welcomeText = "Hello and welcome!";
            foreach (var member in membersAdded)
            {
                if (member.Id != turnContext.Activity.Recipient.Id)
                {
                    await turnContext.SendActivityAsync(MessageFactory.Text(welcomeText, welcomeText), cancellationToken);
                }
            }
        }
        protected override async Task<TaskModuleResponse> OnTeamsTaskModuleFetchAsync(ITurnContext<IInvokeActivity> turnContext, TaskModuleRequest taskModuleRequest, CancellationToken cancellationToken)
        {
            var reply = MessageFactory.Text("OnTeamsTaskModuleFetchAsync TaskModuleRequest: " + JsonConvert.SerializeObject(taskModuleRequest));
            await turnContext.SendActivityAsync(reply);

            return new TaskModuleResponse
            {
                Task = new TaskModuleContinueResponse
                {
                    Value = new TaskModuleTaskInfo()
                    {
                        Card = comments(),
                        Height = 200,
                        Width = 400,
                        Title = "Adaptive Card: Inputs",
                    },
                },
            };
        }

        protected override async Task<TaskModuleResponse> OnTeamsTaskModuleSubmitAsync(ITurnContext<IInvokeActivity> turnContext, TaskModuleRequest taskModuleRequest, CancellationToken cancellationToken)
        {
            var reply = MessageFactory.Text("OnTeamsTaskModuleSubmitAsync Value: " + JsonConvert.SerializeObject(taskModuleRequest));
            await turnContext.SendActivityAsync(reply);

            return new TaskModuleResponse
            {
                Task = new TaskModuleMessageResponse()
                {
                    Value = "Thanks!",
                },
            };
        }

        public static Attachment comments()                //second adaptive card
        {
            AdaptiveCard card = new AdaptiveCard("1.2")
            {
                Body = new List<AdaptiveElement>()
                {
                    new AdaptiveTextBlock()
                    {
                        Text=" Any Comments!",
                        Size=AdaptiveTextSize.Default,
                        Color=AdaptiveTextColor.Dark,
                        HorizontalAlignment=AdaptiveHorizontalAlignment.Left


                    },
                    new AdaptiveTextInput()
                    {
                        Id="commentss",
                        IsMultiline=true
                    }
                    

                },
                Actions = new List<AdaptiveAction>()
                {
                    new AdaptiveSubmitAction()
                    {
                        Title="Send",
                        Type=AdaptiveSubmitAction.TypeName,
                        Style="positive",
                         Data= new Dictionary<string, object>()
                            {
                            {
                            "msteams",new Dictionary<string,string>()
                            {
                            {
                            "type","task/submit"
                            },
                            {
                            "value","{\"Id\":\"commentss\"}"   //value that it takes with it
                            //"value",json
                            }
                            }
                            },
                            {
                            "data","submit"
                            }
                            }
                            }
                }
            };
            Attachment att = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card
            };
            return att;
        }
        //public static Attachment Thankyoucard()      //Third adaptive card

        //{
        //    AdaptiveCard card = new AdaptiveCard("1.2")
        //    {
        //        Body = new List<AdaptiveElement>()
        //        {
        //            new AdaptiveTextBlock()
        //            {
        //                Text = "Thanks!"
        //            }
        //        },

        //    };
        //    Attachment attach = new Attachment()
        //    {
        //        ContentType = AdaptiveCard.ContentType,
        //        Content = card
        //    };
        //    return attach;



            
       //}
        public static Attachment GetAdaptiveCard()
        {
            AdaptiveCard card = new AdaptiveCard("1.2")
            {
                Body = new List<AdaptiveElement>()
                {
                    new AdaptiveTextBlock
                    {
                        Text = "Adaptive card",
                        Size = AdaptiveTextSize.Large,
                        HorizontalAlignment = AdaptiveHorizontalAlignment.Center,
                        Weight = AdaptiveTextWeight.Bolder,

                    },
                    new AdaptiveColumnSet()
                    {
                        Columns = new List<AdaptiveColumn>()
                        {
                            new AdaptiveColumn()
                            {
                                Width = AdaptiveColumnWidth.Auto,
                                Items = new List<AdaptiveElement>()

                                {
                                    new AdaptiveTextBlock
                                    {
                                        Text = "Name"
                                    }
                                }
                            },

                            new AdaptiveColumn()
                            {
                                Items = new List<AdaptiveElement>()

                                {
                                    new AdaptiveTextInput
                                    {
                                        Id = "name",
                                        Placeholder = "Enter your name"

                                    }
                                }
                            },


                        },


                    },


                },
                Actions = new List<AdaptiveAction>()
                {
                 new AdaptiveSubmitAction
                {
                    Title = "Submit",
                    Style = "positive",
                    Type=AdaptiveSubmitAction.TypeName,            //type is imp
                    Data= new Dictionary<string, object>()
                    {
                    {
                    "msteams",new Dictionary<string,string>()
                    {
                    {
                    "type","task/fetch"
                    },
                    {
                    "value","{\"Id\":\"name\"}"   //value that it takes with it
                    //"value",json
                    }
                    }
                    },
                    {
                    "data","submit"
                    }
                    }
                },
                }
            };      //first show adaptive card
            Attachment attachment = new Attachment()
            {
                ContentType = AdaptiveCard.ContentType,
                Content = card,

            };

            return attachment;

        }



    }
}
